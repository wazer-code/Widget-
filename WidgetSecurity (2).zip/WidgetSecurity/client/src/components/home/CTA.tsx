import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

const CTA = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-primary to-blue-500 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6 font-heading">Ready to Secure Your Property?</h2>
        <p className="text-lg mb-8 max-w-2xl mx-auto">
          Contact us today for a free security assessment and personalized quote. Take the first step towards peace of mind.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/contact">
            <Button variant="secondary" size="lg" className="bg-white text-primary hover:bg-gray-100">
              Get a Free Quote
            </Button>
          </Link>
          <Button variant="outline" size="lg" className="border-2 border-white text-white hover:bg-white/10">
            <Phone className="mr-2 h-4 w-4" />
            Call Us Now
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CTA;

import { useQuery } from "@tanstack/react-query";
import { useFAQ } from "@/hooks/useFAQ";
import { FAQ as FAQType } from "@shared/schema";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Skeleton } from "@/components/ui/skeleton";

const FAQItem = ({ faq, value }: { faq: FAQType; value: string }) => {
  return (
    <AccordionItem value={value} className="border border-gray-200 rounded-lg overflow-hidden mb-4 bg-white">
      <AccordionTrigger className="px-4 py-3 font-semibold hover:bg-gray-50 focus:outline-none">
        {faq.question}
      </AccordionTrigger>
      <AccordionContent className="px-4 pb-4 pt-0 text-gray-600">
        {faq.answer}
      </AccordionContent>
    </AccordionItem>
  );
};

const FAQSkeleton = () => (
  <>
    {[1, 2, 3, 4, 5].map((i) => (
      <div key={i} className="border border-gray-200 rounded-lg overflow-hidden mb-4 bg-white p-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-5 w-5 rounded-full" />
        </div>
      </div>
    ))}
  </>
);

const FAQ = () => {
  const { data: faqs, isLoading } = useQuery({
    queryKey: ['/api/faqs'],
  });
  
  const { accordionValue, handleAccordionChange } = useFAQ();

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 font-heading">Frequently Asked Questions</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Find answers to common questions about our security systems and services.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {isLoading ? (
            <FAQSkeleton />
          ) : (
            <Accordion
              type="single"
              collapsible
              value={accordionValue}
              onValueChange={handleAccordionChange}
              className="space-y-4"
            >
              {faqs?.map((faq: FAQType) => (
                <FAQItem 
                  key={faq.id} 
                  faq={faq} 
                  value={faq.id.toString()} 
                />
              ))}
            </Accordion>
          )}
        </div>
      </div>
    </section>
  );
};

export default FAQ;

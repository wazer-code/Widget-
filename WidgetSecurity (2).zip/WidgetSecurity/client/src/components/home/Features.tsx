import { Shield, UserCog, Headphones, Wrench } from "lucide-react";

interface FeatureProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const Feature = ({ icon, title, description }: FeatureProps) => {
  return (
    <div className="apple-card text-center">
      <div className="inline-block p-3 bg-blue-50 rounded-full text-blue-600 mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3 text-black">{title}</h3>
      <p className="text-gray-600 text-sm leading-relaxed">{description}</p>
    </div>
  );
};

const Features = () => {
  const features = [
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Advanced Protection",
      description: "State-of-the-art security systems with cutting-edge technology for maximum protection."
    },
    {
      icon: <UserCog className="h-6 w-6" />,
      title: "Expert Installation",
      description: "Professional installation by certified technicians ensures optimal system performance."
    },
    {
      icon: <Headphones className="h-6 w-6" />,
      title: "24/7 Support",
      description: "Round-the-clock customer support and monitoring services for peace of mind."
    },
    {
      icon: <Wrench className="h-6 w-6" />,
      title: "Custom Solutions",
      description: "Tailored security systems designed to meet your specific requirements and budget."
    }
  ];

  return (
    <section className="apple-section bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="apple-section h2">Why Choose Widget Security?</h2>
          <p className="apple-section p">
            We provide comprehensive security solutions tailored to your specific needs, 
            all backed by our commitment to excellence.
          </p>
        </div>

        <div className="apple-grid">
          {features.map((feature, index) => (
            <Feature
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;

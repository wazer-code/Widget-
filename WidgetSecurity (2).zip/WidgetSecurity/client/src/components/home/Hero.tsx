import { Link } from "wouter";

const Hero = () => {
  return (
    <section className="apple-hero">
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto">
          <h1 className="apple-hero h1">
            Secure Your World
          </h1>
          <p className="apple-hero p">
            Professional security systems that protect what matters most. 
            Advanced technology meets elegant design.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Link href="/products">
              <button className="apple-button">
                Shop Now
              </button>
            </Link>
            <Link href="/contact">
              <button className="apple-button-secondary">
                Learn More
              </button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;

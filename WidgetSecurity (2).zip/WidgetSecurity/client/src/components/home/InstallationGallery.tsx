import { useQuery } from "@tanstack/react-query";
import { GalleryImage } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const GalleryItem = ({ image }: { image: GalleryImage }) => {
  return (
    <div className="gallery-item relative overflow-hidden rounded-lg shadow-md group cursor-pointer">
      <img 
        src={image.imageUrl} 
        alt={image.title} 
        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-gray-800/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
        <div className="p-4 text-white">
          <h3 className="font-bold">{image.title}</h3>
          <p className="text-sm">{image.description}</p>
        </div>
      </div>
    </div>
  );
};

const GallerySkeleton = () => (
  <div className="relative overflow-hidden rounded-lg shadow-md">
    <Skeleton className="w-full h-48 md:h-64" />
  </div>
);

const InstallationGallery = () => {
  const { data: galleryImages, isLoading } = useQuery({
    queryKey: ['/api/gallery'],
  });

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 font-heading">Our Installation Gallery</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Browse our gallery of recent security system installations for homes and businesses.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {isLoading
            ? Array(8)
                .fill(0)
                .map((_, index) => <GallerySkeleton key={index} />)
            : galleryImages?.map((image: GalleryImage) => (
                <GalleryItem key={image.id} image={image} />
              ))}
        </div>
      </div>
    </section>
  );
};

export default InstallationGallery;

import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Heart, Star, StarHalf, ShoppingCart } from "lucide-react";
import { Product } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { useCart } from "@/context/CartContext";
import { useToast } from "@/hooks/use-toast";

const ProductCard = ({ product }: { product: Product }) => {
  const { addToCart } = useCart();
  const { toast } = useToast();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    console.log('Add to cart clicked for product:', product.name);
    console.log('Product details:', product);
    
    try {
      addToCart(product);
      console.log('Product added to cart successfully');
      
      toast({
        title: "Added to Cart",
        description: `${product.name} has been added to your cart`,
      });
      console.log('Toast notification triggered');
    } catch (error) {
      console.error('Error adding to cart:', error);
    }
  };

  const renderRatingStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="fill-amber-500 text-amber-500 h-4 w-4" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="fill-amber-500 text-amber-500 h-4 w-4" />);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-amber-500 h-4 w-4" />);
    }

    return stars;
  };

  return (
    <div className="apple-card group cursor-pointer">
      <div className="h-48 overflow-hidden relative mb-4">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-300 ease-in-out group-hover:scale-105"
        />
      </div>
      <h3 className="text-lg font-semibold mb-2 text-black">{product.name}</h3>
      <div className="flex justify-between items-center mb-3">
        <span className="text-blue-600 font-semibold text-lg">${product.price.toFixed(2)}</span>
        <div className="flex">
          {renderRatingStars(product.rating)}
        </div>
      </div>
      <p className="text-gray-600 text-sm mb-4 line-clamp-2">{product.description}</p>
      <div className="flex flex-wrap gap-1 mb-4">
        {product.features.slice(0, 3).map((feature, index) => (
          <span key={index} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
            {feature}
          </span>
        ))}
      </div>
      <div className="flex space-x-2">
        <Link href={`/products/${product.id}`} className="flex-1">
          <button className="apple-button w-full">
            View Details
          </button>
        </Link>
        <button 
          onClick={handleAddToCart}
          className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
        >
          <ShoppingCart className="h-4 w-4 text-gray-600" />
        </button>
        <button className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors">
          <Heart className="h-4 w-4 text-gray-600" />
        </button>
      </div>
    </div>
  );
};

const ProductsSection = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setIsLoading(true);
        console.log('Fetching products from /api/products...');
        const response = await fetch("/api/products");
        console.log('Response status:', response.status);
        if (!response.ok) {
          throw new Error("Failed to fetch products");
        }
        const data = await response.json();
        console.log('Products data:', data);
        setProducts(data);
        setError(null);
      } catch (err) {
        console.error('Error fetching products:', err);
        setError(err instanceof Error ? err.message : "Failed to fetch products");
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const filteredProducts = products.filter((product: Product) => {
    if (selectedCategory === "all") return true;
    return product.category === selectedCategory;
  });

  const categories = [
    { id: "all", name: "All Products" },
    { id: "cctv", name: "CCTV Systems" },
    { id: "alarm", name: "Alarm Systems" },
    { id: "access", name: "Access Control" },
    { id: "smart", name: "Smart Security" },
    { id: "commercial", name: "Commercial" },
    { id: "residential", name: "Residential" },
  ];

  if (error) {
    return (
      <section className="apple-section">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h2 className="apple-section h2">Featured Products</h2>
            <p className="apple-section p">
              Discover our latest security solutions designed to protect your home and business.
            </p>
            <p className="text-red-500">Error loading products: {error}</p>
            <button 
              onClick={() => window.location.reload()} 
              className="apple-button mt-4"
            >
              Retry
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="apple-section">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="apple-section h2">Featured Products</h2>
          <p className="apple-section p">
            Discover our latest security solutions designed to protect your home and business.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category.id
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="apple-grid">
            {[...Array(4)].map((_, index) => (
              <div key={index} className="apple-card">
                <Skeleton className="h-48 w-full mb-4" />
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2 mb-4" />
                <Skeleton className="h-4 w-full mb-4" />
                <Skeleton className="h-10 w-full" />
              </div>
            ))}
          </div>
        ) : (
          <>
            <div className="apple-grid">
              {filteredProducts.slice(0, 4).map((product: Product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
            
            <div className="text-center mt-12">
              <Link href="/products">
                <button className="apple-button-secondary">
                  View All Products
                </button>
              </Link>
            </div>
          </>
        )}
      </div>
    </section>
  );
};

export default ProductsSection;

import { useQuery } from "@tanstack/react-query";
import { Service } from "@shared/schema";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const iconMap: Record<string, JSX.Element> = {
  "fa-tools": <i className="fas fa-tools text-primary text-2xl"></i>,
  "fa-shield-alt": <i className="fas fa-shield-alt text-primary text-2xl"></i>,
  "fa-wrench": <i className="fas fa-wrench text-primary text-2xl"></i>,
  "fa-clipboard-check": <i className="fas fa-clipboard-check text-primary text-2xl"></i>,
  "fa-graduation-cap": <i className="fas fa-graduation-cap text-primary text-2xl"></i>,
  "fa-sync-alt": <i className="fas fa-sync-alt text-primary text-2xl"></i>,
};

const ServiceCard = ({ service }: { service: Service }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      <div className="p-1 bg-primary"></div>
      <div className="p-6">
        <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mb-4">
          {iconMap[service.icon] || <i className="fas fa-cog text-primary text-2xl"></i>}
        </div>
        <h3 className="text-xl font-bold mb-3 font-heading">{service.name}</h3>
        <p className="text-gray-600 mb-4">
          {service.description}
        </p>
        <ul className="space-y-2 mb-6">
          {service.benefits.map((benefit, index) => (
            <li key={index} className="flex items-start">
              <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
              <span>{benefit}</span>
            </li>
          ))}
        </ul>
        <a href="#" className="text-primary hover:text-secondary font-medium inline-flex items-center">
          Learn More <ArrowRight className="ml-2 h-4 w-4" />
        </a>
      </div>
    </div>
  );
};

const ServiceSkeleton = () => (
  <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-md">
    <div className="p-1 bg-gray-300"></div>
    <div className="p-6">
      <Skeleton className="w-14 h-14 rounded-full mb-4" />
      <Skeleton className="h-7 w-1/2 mb-3" />
      <Skeleton className="h-4 w-full mb-2" />
      <Skeleton className="h-4 w-full mb-2" />
      <Skeleton className="h-4 w-2/3 mb-4" />
      <div className="space-y-2 mb-6">
        <div className="flex items-start">
          <Skeleton className="h-4 w-4 mt-1 mr-2" />
          <Skeleton className="h-4 w-5/6" />
        </div>
        <div className="flex items-start">
          <Skeleton className="h-4 w-4 mt-1 mr-2" />
          <Skeleton className="h-4 w-3/4" />
        </div>
        <div className="flex items-start">
          <Skeleton className="h-4 w-4 mt-1 mr-2" />
          <Skeleton className="h-4 w-4/5" />
        </div>
      </div>
      <Skeleton className="h-5 w-28" />
    </div>
  </div>
);

const ServicesSection = () => {
  const { data: services, isLoading } = useQuery({
    queryKey: ['/api/services'],
  });

  return (
    <section id="services" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 font-heading">Our Services</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We offer comprehensive security services to ensure your system works perfectly and provides maximum protection.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {isLoading
            ? Array(6)
                .fill(0)
                .map((_, index) => <ServiceSkeleton key={index} />)
            : services?.map((service: Service) => (
                <ServiceCard key={service.id} service={service} />
              ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;

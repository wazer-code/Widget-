import { useQuery } from "@tanstack/react-query";
import { useTestimonialSlider } from "@/hooks/useTestimonialSlider";
import { Testimonial } from "@shared/schema";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";

const TestimonialCard = ({ testimonial }: { testimonial: Testimonial }) => {
  return (
    <div className="testimonial-slide w-full md:w-1/2 lg:w-1/3 flex-shrink-0 px-4">
      <div className="bg-white text-gray-800 p-6 rounded-lg shadow-md relative h-full">
        <div className="absolute -top-5 left-6 w-10 h-10 bg-white rounded-full border-4 border-primary flex items-center justify-center">
          <Quote className="h-4 w-4 text-primary" />
        </div>
        <div className="pt-4">
          <p className="mb-6 italic">
            "{testimonial.content}"
          </p>
          <div className="flex items-center">
            <div className="w-12 h-12 bg-gray-200 rounded-full overflow-hidden mr-4">
              <img src={testimonial.imageUrl} alt={testimonial.name} className="w-full h-full object-cover" />
            </div>
            <div>
              <h4 className="font-semibold">{testimonial.name}</h4>
              <p className="text-sm text-gray-600">{testimonial.role}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const TestimonialSkeleton = () => (
  <div className="testimonial-slide w-full md:w-1/2 lg:w-1/3 flex-shrink-0 px-4">
    <div className="bg-white text-gray-800 p-6 rounded-lg shadow-md relative h-full">
      <Skeleton className="absolute -top-5 left-6 w-10 h-10 rounded-full" />
      <div className="pt-4">
        <Skeleton className="h-4 w-full mb-2" />
        <Skeleton className="h-4 w-full mb-2" />
        <Skeleton className="h-4 w-2/3 mb-6" />
        <div className="flex items-center">
          <Skeleton className="w-12 h-12 rounded-full mr-4" />
          <div>
            <Skeleton className="h-4 w-24 mb-2" />
            <Skeleton className="h-3 w-16" />
          </div>
        </div>
      </div>
    </div>
  </div>
);

const Testimonials = () => {
  const { data: testimonials, isLoading } = useQuery({
    queryKey: ['/api/testimonials'],
  });

  const {
    currentIndex,
    slidesToShow,
    handlePrevious,
    handleNext,
    setCurrentIndex,
    containerStyle
  } = useTestimonialSlider(testimonials?.length || 0);

  return (
    <section className="py-16 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 font-heading">What Our Clients Say</h2>
          <p className="text-lg max-w-3xl mx-auto opacity-90">
            Read testimonials from our satisfied customers who trust Widget for their security needs.
          </p>
        </div>

        <div className="testimonial-slider relative">
          <div className="overflow-hidden">
            <div 
              className="testimonials-container flex transition-transform duration-500"
              style={containerStyle}
            >
              {isLoading
                ? Array(3)
                    .fill(0)
                    .map((_, index) => <TestimonialSkeleton key={index} />)
                : testimonials?.map((testimonial: Testimonial) => (
                    <TestimonialCard key={testimonial.id} testimonial={testimonial} />
                  ))}
            </div>
          </div>

          <Button
            variant="secondary"
            size="icon"
            className="testimonial-prev absolute top-1/2 left-0 -translate-y-1/2 bg-white text-primary rounded-full z-10 hover:bg-gray-100"
            onClick={handlePrevious}
            disabled={currentIndex === 0}
          >
            <ChevronLeft className="h-5 w-5" />
          </Button>
          
          <Button
            variant="secondary"
            size="icon"
            className="testimonial-next absolute top-1/2 right-0 -translate-y-1/2 bg-white text-primary rounded-full z-10 hover:bg-gray-100"
            onClick={handleNext}
            disabled={currentIndex >= (testimonials?.length || 0) - slidesToShow}
          >
            <ChevronRight className="h-5 w-5" />
          </Button>

          <div className="flex justify-center mt-8 gap-2 testimonial-dots">
            {testimonials?.map((_: any, index: number) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentIndex ? 'bg-white' : 'bg-white/30'
                }`}
                onClick={() => setCurrentIndex(index)}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;

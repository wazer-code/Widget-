import { Link } from "wouter";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <Link href="/" className="text-2xl font-bold flex items-center mb-4 text-black">
              <img 
                src="/assets/IMG_0826.png" 
                alt="Commercial Security Kit" 
                className="h-8 w-8 mr-3 object-cover rounded-lg shadow-sm"
              />
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Commercial Security Kit
              </span>
            </Link>
            <p className="mb-4 text-gray-600 text-sm">
              Providing industry-leading security solutions to protect what matters most to you.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-8 h-8 bg-gray-200 hover:bg-gray-300 text-gray-600 rounded-full flex items-center justify-center transition-colors hover-lift">
                <FaFacebookF className="h-3 w-3" />
              </a>
              <a href="#" className="w-8 h-8 bg-gray-200 hover:bg-gray-300 text-gray-600 rounded-full flex items-center justify-center transition-colors hover-lift">
                <FaTwitter className="h-3 w-3" />
              </a>
              <a href="#" className="w-8 h-8 bg-gray-200 hover:bg-gray-300 text-gray-600 rounded-full flex items-center justify-center transition-colors hover-lift">
                <FaLinkedinIn className="h-3 w-3" />
              </a>
              <a href="#" className="w-8 h-8 bg-gray-200 hover:bg-gray-300 text-gray-600 rounded-full flex items-center justify-center transition-colors hover-lift">
                <FaInstagram className="h-3 w-3" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-black">Products</h3>
            <ul className="space-y-2">
              <li><Link href="/products?category=cctv" className="text-gray-600 hover:text-black transition-colors text-sm">CCTV Systems</Link></li>
              <li><Link href="/products?category=alarm" className="text-gray-600 hover:text-black transition-colors text-sm">Alarm Systems</Link></li>
              <li><Link href="/products?category=access" className="text-gray-600 hover:text-black transition-colors text-sm">Access Control</Link></li>
              <li><Link href="/products?category=smart" className="text-gray-600 hover:text-black transition-colors text-sm">Smart Security</Link></li>
              <li><Link href="/products" className="text-gray-600 hover:text-black transition-colors text-sm">Commercial Security</Link></li>
              <li><Link href="/products" className="text-gray-600 hover:text-black transition-colors text-sm">Residential Security</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-black">Services</h3>
            <ul className="space-y-2">
              <li><Link href="/services" className="text-gray-600 hover:text-black transition-colors text-sm">Installation</Link></li>
              <li><Link href="/services" className="text-gray-600 hover:text-black transition-colors text-sm">24/7 Monitoring</Link></li>
              <li><Link href="/services" className="text-gray-600 hover:text-black transition-colors text-sm">Maintenance & Repair</Link></li>
              <li><Link href="/services" className="text-gray-600 hover:text-black transition-colors text-sm">Security Assessment</Link></li>
              <li><Link href="/services" className="text-gray-600 hover:text-black transition-colors text-sm">System Training</Link></li>
              <li><Link href="/services" className="text-gray-600 hover:text-black transition-colors text-sm">System Upgrades</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4 text-black">Contact</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin className="mt-1 mr-3 text-blue-600" size={16} />
                <span className="text-gray-600 text-sm">123 Security Ave, Safetown, ST 12345</span>
              </li>
              <li className="flex items-start">
                <Phone className="mt-1 mr-3 text-blue-600" size={16} />
                <span className="text-gray-600 text-sm">(123) 456-7890</span>
              </li>
              <li className="flex items-start">
                <Mail className="mt-1 mr-3 text-blue-600" size={16} />
                <span className="text-gray-600 text-sm">info@commercialsecuritykit.com</span>
              </li>
              <li className="flex items-start">
                <Clock className="mt-1 mr-3 text-blue-600" size={16} />
                <span className="text-gray-600 text-sm">Mon-Fri: 8:00 AM - 6:00 PM</span>
              </li>
            </ul>
          </div>
        </div>
        
        <hr className="border-gray-200 mb-8" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 mb-4 md:mb-0 text-sm">
            &copy; {new Date().getFullYear()} Commercial Security Kit. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <Link href="/privacy" className="text-gray-500 hover:text-black transition-colors text-sm">Privacy Policy</Link>
            <Link href="/terms" className="text-gray-500 hover:text-black transition-colors text-sm">Terms of Service</Link>
            <Link href="/sitemap" className="text-gray-500 hover:text-black transition-colors text-sm">Sitemap</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

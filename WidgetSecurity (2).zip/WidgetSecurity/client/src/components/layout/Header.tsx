import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, ShoppingCart } from "lucide-react";
import { useCart } from "@/context/CartContext";

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { getTotalItems } = useCart();

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <header className="apple-nav sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <nav className="flex items-center justify-between py-4">
          <div className="flex items-center">
            <Link href="/" className="font-bold text-2xl text-black flex items-center">
              <img 
                src="/assets/IMG_0826.png" 
                alt="Commercial Security Kit" 
                className="h-10 w-10 mr-3 object-cover rounded-lg shadow-sm"
              />
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Commercial Security Kit
              </span>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button 
              onClick={toggleMenu}
              aria-label="Toggle menu"
              className="p-2 text-black hover:bg-gray-100 rounded-lg transition-colors"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              href="/" 
              className={`text-sm font-medium transition-all duration-300 hover:scale-105 ${isActive('/') ? 'text-blue-600' : 'text-gray-600 hover:text-black'}`}
            >
              Home
            </Link>
            
            <Link 
              href="/products" 
              className={`text-sm font-medium transition-all duration-300 hover:scale-105 ${isActive('/products') ? 'text-blue-600' : 'text-gray-600 hover:text-black'}`}
            >
              Products
            </Link>
            
            <Link 
              href="/services" 
              className={`text-sm font-medium transition-all duration-300 hover:scale-105 ${isActive('/services') ? 'text-blue-600' : 'text-gray-600 hover:text-black'}`}
            >
              Services
            </Link>
            
            <Link 
              href="/about" 
              className={`text-sm font-medium transition-all duration-300 hover:scale-105 ${isActive('/about') ? 'text-blue-600' : 'text-gray-600 hover:text-black'}`}
            >
              About
            </Link>
            
            <Link 
              href="/contact" 
              className={`text-sm font-medium transition-all duration-300 hover:scale-105 ${isActive('/contact') ? 'text-blue-600' : 'text-gray-600 hover:text-black'}`}
            >
              Contact
            </Link>

            <Link 
              href="/admin" 
              className={`text-sm font-medium transition-all duration-300 hover:scale-105 ${isActive('/admin') ? 'text-blue-600' : 'text-gray-600 hover:text-black'}`}
            >
              Admin
            </Link>
          </div>

          {/* Cart Icon */}
          <div className="flex items-center space-x-4">
            <Link href="/cart" className="relative group">
              <div className="p-2 bg-gray-100 hover:bg-gray-200 rounded-full transition-all duration-300 group-hover:scale-110">
                <ShoppingCart className="h-6 w-6 text-gray-600 group-hover:text-black transition-colors" />
              </div>
              {getTotalItems() > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center animate-pulse">
                  {getTotalItems()}
                </span>
              )}
            </Link>
          </div>
        </nav>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden bg-white border-t border-gray-200 animate-in slide-in-from-top-2 duration-300">
            <div className="px-4 py-2 space-y-2">
              <Link 
                href="/" 
                onClick={closeMenu}
                className={`block py-3 text-sm font-medium border-b border-gray-100 ${isActive('/') ? 'text-blue-600' : 'text-gray-600'}`}
              >
                Home
              </Link>
              <Link 
                href="/products" 
                onClick={closeMenu}
                className={`block py-3 text-sm font-medium border-b border-gray-100 ${isActive('/products') ? 'text-blue-600' : 'text-gray-600'}`}
              >
                Products
              </Link>
              <Link 
                href="/services" 
                onClick={closeMenu}
                className={`block py-3 text-sm font-medium border-b border-gray-100 ${isActive('/services') ? 'text-blue-600' : 'text-gray-600'}`}
              >
                Services
              </Link>
              <Link 
                href="/about" 
                onClick={closeMenu}
                className={`block py-3 text-sm font-medium border-b border-gray-100 ${isActive('/about') ? 'text-blue-600' : 'text-gray-600'}`}
              >
                About
              </Link>
              <Link 
                href="/contact" 
                onClick={closeMenu}
                className={`block py-3 text-sm font-medium border-b border-gray-100 ${isActive('/contact') ? 'text-blue-600' : 'text-gray-600'}`}
              >
                Contact
              </Link>
              <Link 
                href="/admin" 
                onClick={closeMenu}
                className={`block py-3 text-sm font-medium ${isActive('/admin') ? 'text-blue-600' : 'text-gray-600'}`}
              >
                Admin
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;

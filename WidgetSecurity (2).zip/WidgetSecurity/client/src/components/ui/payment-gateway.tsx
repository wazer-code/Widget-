import { useState } from "react";
import { CreditCard, Lock, Shield, CheckCircle } from "lucide-react";

interface PaymentMethod {
  id: string;
  name: string;
  icon: string;
  description: string;
}

interface PaymentGatewayProps {
  amount: number;
  onPaymentSuccess: (paymentData: any) => void;
  onPaymentError: (error: string) => void;
}

const PaymentGateway = ({ amount, onPaymentSuccess, onPaymentError }: PaymentGatewayProps) => {
  const [selectedMethod, setSelectedMethod] = useState<string>("card");
  const [isProcessing, setIsProcessing] = useState(false);
  const [cardNumber, setCardNumber] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [cardholderName, setCardholderName] = useState("");

  const paymentMethods: PaymentMethod[] = [
    {
      id: "card",
      name: "Credit Card",
      icon: "💳",
      description: "Visa, Mastercard, American Express"
    },
    {
      id: "paypal",
      name: "PayPal",
      icon: "🔵",
      description: "Fast and secure payments"
    },
    {
      id: "apple-pay",
      name: "Apple Pay",
      icon: "🍎",
      description: "Quick and easy checkout"
    },
    {
      id: "google-pay",
      name: "Google Pay",
      icon: "🔴",
      description: "Contactless payment"
    }
  ];

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      const success = Math.random() > 0.1; // 90% success rate for demo
      
      if (success) {
        onPaymentSuccess({
          method: selectedMethod,
          amount,
          transactionId: `TXN-${Date.now()}`,
          timestamp: new Date().toISOString()
        });
      } else {
        onPaymentError("Payment failed. Please try again.");
      }
      
      setIsProcessing(false);
    }, 2000);
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    const matches = v.match(/\d{4,16}/g);
    const match = matches && matches[0] || "";
    const parts = [];
    
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }
    
    if (parts.length) {
      return parts.join(" ");
    } else {
      return v;
    }
  };

  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "");
    if (v.length >= 2) {
      return v.substring(0, 2) + "/" + v.substring(2, 4);
    }
    return v;
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-2xl shadow-xl p-8 animate-scale-in">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <Lock className="h-8 w-8 text-blue-600 mr-3" />
          <h3 className="text-2xl font-semibold text-gray-800">Secure Payment</h3>
        </div>
        <p className="text-gray-600">Complete your purchase securely</p>
      </div>

      {/* Payment Methods */}
      <div className="mb-8">
        <h4 className="text-lg font-medium text-gray-800 mb-4">Choose Payment Method</h4>
        <div className="grid grid-cols-2 gap-3">
          {paymentMethods.map((method) => (
            <button
              key={method.id}
              onClick={() => setSelectedMethod(method.id)}
              className={`payment-method ${
                selectedMethod === method.id ? "selected" : ""
              }`}
            >
              <div className="text-2xl mb-2">{method.icon}</div>
              <div className="text-sm font-medium text-gray-800">{method.name}</div>
              <div className="text-xs text-gray-500">{method.description}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Payment Form */}
      {selectedMethod === "card" && (
        <form onSubmit={handlePayment} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Card Number
            </label>
            <div className="relative">
              <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={cardNumber}
                onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                placeholder="1234 5678 9012 3456"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                maxLength={19}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Expiry Date
              </label>
              <input
                type="text"
                value={expiryDate}
                onChange={(e) => setExpiryDate(formatExpiryDate(e.target.value))}
                placeholder="MM/YY"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                maxLength={5}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                CVV
              </label>
              <input
                type="text"
                value={cvv}
                onChange={(e) => setCvv(e.target.value.replace(/\D/g, ""))}
                placeholder="123"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                maxLength={4}
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cardholder Name
            </label>
            <input
              type="text"
              value={cardholderName}
              onChange={(e) => setCardholderName(e.target.value)}
              placeholder="John Doe"
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
              required
            />
          </div>
        </form>
      )}

      {/* Other Payment Methods */}
      {selectedMethod !== "card" && (
        <div className="text-center py-8">
          <div className="text-4xl mb-4">{paymentMethods.find(m => m.id === selectedMethod)?.icon}</div>
          <p className="text-gray-600 mb-6">
            You'll be redirected to complete your payment securely.
          </p>
        </div>
      )}

      {/* Total Amount */}
      <div className="border-t border-gray-200 pt-6 mb-6">
        <div className="flex justify-between items-center">
          <span className="text-lg font-medium text-gray-800">Total Amount</span>
          <span className="text-2xl font-bold text-blue-600">${amount.toFixed(2)}</span>
        </div>
      </div>

      {/* Security Notice */}
      <div className="bg-blue-50 rounded-lg p-4 mb-6">
        <div className="flex items-center">
          <Shield className="h-5 w-5 text-blue-600 mr-2" />
          <span className="text-sm text-blue-800">
            Your payment is secured with bank-level encryption
          </span>
        </div>
      </div>

      {/* Pay Button */}
      <button
        onClick={handlePayment}
        disabled={isProcessing}
        className="w-full apple-button flex items-center justify-center"
      >
        {isProcessing ? (
          <>
            <div className="loading-spinner mr-3"></div>
            Processing Payment...
          </>
        ) : (
          <>
            <Lock className="h-5 w-5 mr-2" />
            Pay ${amount.toFixed(2)}
          </>
        )}
      </button>

      {/* Terms */}
      <p className="text-xs text-gray-500 text-center mt-4">
        By clicking "Pay", you agree to our Terms of Service and Privacy Policy
      </p>
    </div>
  );
};

export default PaymentGateway;


import { useState } from "react";

export function useFAQ() {
  const [accordionValue, setAccordionValue] = useState<string | undefined>(undefined);
  
  const handleAccordionChange = (value: string) => {
    setAccordionValue(value);
  };
  
  return {
    accordionValue,
    handleAccordionChange
  };
}

import { useState } from "react";

export function useProductCategory() {
  const [category, setCategory] = useState("all");
  const [sortOption, setSortOption] = useState("latest");

  return {
    category,
    setCategory,
    sortOption,
    setSortOption
  };
}

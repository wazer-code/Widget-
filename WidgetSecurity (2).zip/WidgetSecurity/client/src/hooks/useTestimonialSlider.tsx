import { useState, useEffect } from "react";
import { useMediaQuery } from "@/hooks/use-mobile";

export function useTestimonialSlider(totalItems: number) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [slidesToShow, setSlidesToShow] = useState(3);
  
  const isMobile = useMediaQuery("(max-width: 768px)");
  const isTablet = useMediaQuery("(min-width: 769px) and (max-width: 1023px)");
  
  useEffect(() => {
    if (isMobile) {
      setSlidesToShow(1);
    } else if (isTablet) {
      setSlidesToShow(2);
    } else {
      setSlidesToShow(3);
    }
  }, [isMobile, isTablet]);
  
  const handlePrevious = () => {
    setCurrentIndex(Math.max(0, currentIndex - 1));
  };
  
  const handleNext = () => {
    const maxIndex = Math.max(0, totalItems - slidesToShow);
    setCurrentIndex(Math.min(maxIndex, currentIndex + 1));
  };
  
  const containerStyle = {
    transform: `translateX(-${currentIndex * (100 / slidesToShow)}%)`,
  };
  
  return {
    currentIndex,
    slidesToShow,
    handlePrevious,
    handleNext,
    setCurrentIndex,
    containerStyle
  };
}

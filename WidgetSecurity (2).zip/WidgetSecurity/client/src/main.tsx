import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { ScrollToTop } from "./components/layout/ScrollToTop";

createRoot(document.getElementById("root")!).render(
  <>
    <ScrollToTop />
    <App />
  </>
);

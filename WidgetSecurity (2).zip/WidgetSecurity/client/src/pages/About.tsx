import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Shield, TrendingUp, Award, Clock, CheckCircle2 } from "lucide-react";

const About = () => {
  return (
    <div className="container mx-auto px-4 py-16 page-transition">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 font-heading">About Widget Security</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Providing industry-leading security solutions for homes and businesses since 2005.
          Our mission is to protect what matters most to you.
        </p>
      </div>

      {/* Our Story */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
        <div>
          <h2 className="text-2xl font-bold mb-4 font-heading">Our Story</h2>
          <p className="text-gray-600 mb-4">
            Founded in 2005, Widget Security began with a simple mission: to provide reliable and 
            affordable security solutions that give people peace of mind. What started as a small
            team of security experts has grown into a trusted provider of cutting-edge security systems and services.
          </p>
          <p className="text-gray-600 mb-4">
            Over the years, we've expanded our offerings to include the latest in security technology, 
            from high-definition surveillance cameras to smart home integration. Despite our growth, 
            our commitment to personalized service and customer satisfaction remains unchanged.
          </p>
          <p className="text-gray-600">
            Today, we protect thousands of homes and businesses across the country, with a team of certified
            security professionals dedicated to keeping our customers safe.
          </p>
        </div>
        <div className="rounded-lg overflow-hidden shadow-lg">
          <img 
            src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1000&h=600" 
            alt="Widget Security Team" 
            className="w-full h-auto"
          />
        </div>
      </div>

      {/* Our Values */}
      <div className="bg-gray-50 rounded-lg p-10 mb-20">
        <h2 className="text-2xl font-bold mb-8 font-heading text-center">Our Core Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Shield className="text-primary h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">Reliability</h3>
            <p className="text-gray-600">
              We deliver security solutions you can count on, 24/7/365. Your safety is never compromised.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <TrendingUp className="text-primary h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">Innovation</h3>
            <p className="text-gray-600">
              We constantly seek out and implement the latest security technologies to stay ahead of threats.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Award className="text-primary h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">Excellence</h3>
            <p className="text-gray-600">
              We hold ourselves to the highest standards in every aspect of our business.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Clock className="text-primary h-6 w-6" />
            </div>
            <h3 className="text-xl font-bold mb-2 font-heading">Responsiveness</h3>
            <p className="text-gray-600">
              When security matters are at stake, prompt service and quick response times are essential.
            </p>
          </div>
        </div>
      </div>

      {/* Our Team */}
      <div className="mb-20">
        <h2 className="text-2xl font-bold mb-8 font-heading text-center">Our Leadership Team</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white rounded-lg overflow-hidden shadow-md">
            <img 
              src="https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=500&h=300" 
              alt="David Wilson" 
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-bold mb-1 font-heading">David Wilson</h3>
              <p className="text-primary mb-3">CEO & Founder</p>
              <p className="text-gray-600 mb-4">
                With over 20 years of experience in security systems, David founded Widget Security 
                with a vision to make advanced security accessible to everyone.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg overflow-hidden shadow-md">
            <img 
              src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=500&h=300" 
              alt="Jennifer Martinez" 
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-bold mb-1 font-heading">Jennifer Martinez</h3>
              <p className="text-primary mb-3">Chief Technology Officer</p>
              <p className="text-gray-600 mb-4">
                Jennifer leads our product development team, ensuring that Widget's security solutions 
                incorporate the latest technological advancements.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg overflow-hidden shadow-md">
            <img 
              src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=500&h=300" 
              alt="Michael Chang" 
              className="w-full h-64 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-bold mb-1 font-heading">Michael Chang</h3>
              <p className="text-primary mb-3">Director of Operations</p>
              <p className="text-gray-600 mb-4">
                Michael ensures that our installation and service teams deliver exceptional 
                quality and customer satisfaction on every project.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Certifications */}
      <div className="bg-white border border-gray-200 rounded-lg p-10 mb-20">
        <h2 className="text-2xl font-bold mb-8 font-heading text-center">Certifications & Partnerships</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex flex-col items-center text-center">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <i className="fas fa-certificate text-primary text-3xl"></i>
            </div>
            <h3 className="text-lg font-bold mb-2 font-heading">NSCA Certified</h3>
            <p className="text-gray-600">
              Certified by the National Security Contractors Association for excellence in security installation.
            </p>
          </div>
          
          <div className="flex flex-col items-center text-center">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <i className="fas fa-shield-alt text-primary text-3xl"></i>
            </div>
            <h3 className="text-lg font-bold mb-2 font-heading">UL Listed</h3>
            <p className="text-gray-600">
              Our systems meet the rigorous safety standards set by Underwriters Laboratories.
            </p>
          </div>
          
          <div className="flex flex-col items-center text-center">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <i className="fas fa-handshake text-primary text-3xl"></i>
            </div>
            <h3 className="text-lg font-bold mb-2 font-heading">Strategic Partners</h3>
            <p className="text-gray-600">
              Partnerships with leading security technology manufacturers ensure we offer the best products.
            </p>
          </div>
        </div>
      </div>

      {/* Service Area */}
      <div className="mb-20">
        <h2 className="text-2xl font-bold mb-8 font-heading text-center">Our Service Area</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-gray-600 mb-4">
              Widget Security proudly serves residential and commercial clients throughout the metropolitan area 
              and surrounding communities. Our service area includes:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                  <span>Downtown & Central Districts</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                  <span>Northern Suburbs</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                  <span>Eastern Region</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                  <span>Southern Communities</span>
                </li>
              </ul>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                  <span>Western Neighborhoods</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                  <span>Surrounding Counties</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                  <span>Business Districts</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                  <span>Industrial Areas</span>
                </li>
              </ul>
            </div>
            <p className="text-gray-600 mb-6">
              Not sure if you're within our service area? Contact us today and our team will be happy to assist you.
            </p>
            <Link href="/contact">
              <Button>Contact Us</Button>
            </Link>
          </div>
          <div className="bg-gray-100 rounded-lg overflow-hidden shadow-md">
            <img 
              src="https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=800&h=500" 
              alt="Service Area Map" 
              className="w-full h-auto"
            />
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-primary text-white rounded-lg p-10 text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-4 font-heading">Ready to Enhance Your Security?</h2>
        <p className="text-lg mb-8 max-w-2xl mx-auto">
          Contact Widget Security today for a free security assessment and personalized quote.
          Our experts are ready to design a system that perfectly meets your needs.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Link href="/contact">
            <Button variant="secondary" size="lg" className="bg-white text-primary hover:bg-gray-100">
              Get a Free Quote
            </Button>
          </Link>
          <Link href="/products">
            <Button variant="outline" size="lg" className="border-2 border-primary bg-white text-primary hover:bg-primary hover:text-white glitch-btn ripple">
              Browse Products
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default About;

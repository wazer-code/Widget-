import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Trash2, Edit, Plus, Package, Users, ShoppingCart, LogOut } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import ProtectedRoute from "@/components/ProtectedRoute";
import type { Product, ContactSubmission, CustomerOrder, InsertProduct } from "@shared/schema";
import { insertProductSchema } from "@shared/schema";
import { z } from "zod";

// Simple form data type for input handling
type ProductFormData = {
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  category: string;
  rating: number;
  features: string; // Will be converted to array before sending to API
};

const orderStatusColors = {
  pending: "orange",
  confirmed: "blue", 
  completed: "green",
  cancelled: "red"
} as const;

function AdminContent() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { logout } = useAuth();
  const [, setLocation] = useLocation();
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isProductDialogOpen, setIsProductDialogOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setLocation("/login");
    toast({ title: "Logged out", description: "You have been logged out successfully" });
  };

  // Queries
  const { data: products = [], isLoading: productsLoading } = useQuery({
    queryKey: ['/api/products']
  });

  const { data: contacts = [], isLoading: contactsLoading } = useQuery({
    queryKey: ['/api/admin/contacts']
  });

  const { data: orders = [], isLoading: ordersLoading } = useQuery({
    queryKey: ['/api/admin/orders']
  });

  // Product form
  const productForm = useForm<ProductFormData>({
    defaultValues: {
      name: '',
      description: '',
      price: 0,
      imageUrl: '',
      category: 'cctv',
      rating: 0,
      features: ''
    }
  });

  // Mutations
  const createProductMutation = useMutation({
    mutationFn: async (data: ProductFormData) => {
      const productData = {
        ...data,
        features: data.features.split(',').map(f => f.trim()).filter(f => f.length > 0)
      };
      const response = await fetch('/api/admin/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData)
      });
      if (!response.ok) throw new Error('Failed to create product');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({ title: "Success", description: "Product created successfully" });
      setIsProductDialogOpen(false);
      productForm.reset();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create product", variant: "destructive" });
    }
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<ProductFormData> }) => {
      const productData = {
        ...data,
        features: data.features ? data.features.split(',').map(f => f.trim()).filter(f => f.length > 0) : undefined
      };
      const response = await fetch(`/api/admin/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productData)
      });
      if (!response.ok) throw new Error('Failed to update product');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({ title: "Success", description: "Product updated successfully" });
      setIsProductDialogOpen(false);
      setEditingProduct(null);
      productForm.reset();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update product", variant: "destructive" });
    }
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await fetch(`/api/admin/products/${id}`, { method: 'DELETE' });
      if (!response.ok) throw new Error('Failed to delete product');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({ title: "Success", description: "Product deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete product", variant: "destructive" });
    }
  });

  const updateOrderStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      const response = await fetch(`/api/admin/orders/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (!response.ok) throw new Error('Failed to update order status');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/orders'] });
      toast({ title: "Success", description: "Order status updated successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update order status", variant: "destructive" });
    }
  });

  const handleProductSubmit = (data: ProductFormData) => {
    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, data });
    } else {
      createProductMutation.mutate(data);
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    productForm.reset({
      name: product.name,
      description: product.description,
      price: product.price,
      imageUrl: product.imageUrl,
      category: product.category,
      rating: product.rating,
      features: product.features.join(', ')
    });
    setIsProductDialogOpen(true);
  };

  const handleDeleteProduct = (id: number) => {
    if (confirm('Are you sure you want to delete this product?')) {
      deleteProductMutation.mutate(id);
    }
  };

  const handleUpdateOrderStatus = (orderId: number, status: string) => {
    updateOrderStatusMutation.mutate({ id: orderId, status });
  };

  return (
    <div className="min-h-screen bg-gray-50 animate-in fade-in duration-500">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 flex justify-between items-center animate-in slide-in-from-top-4 duration-500">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
            <p className="text-gray-600 mt-2">Manage your security systems business</p>
          </div>
          <Button variant="outline" onClick={handleLogout} className="flex items-center gap-2 hover:bg-red-50 hover:border-red-200 transition-all duration-300">
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>

        <Tabs defaultValue="products" className="space-y-6 animate-in slide-in-from-bottom-4 duration-700">
          <TabsList className="grid w-full grid-cols-3 animate-in slide-in-from-bottom-2 duration-500 delay-200">
            <TabsTrigger value="products" className="flex items-center gap-2 transition-all duration-300 hover:scale-105 data-[state=active]:bg-primary data-[state=active]:text-white">
              <Package className="h-4 w-4" />
              Products
            </TabsTrigger>
            <TabsTrigger value="contacts" className="flex items-center gap-2 transition-all duration-300 hover:scale-105 data-[state=active]:bg-primary data-[state=active]:text-white">
              <Users className="h-4 w-4" />
              Contacts
            </TabsTrigger>
            <TabsTrigger value="orders" className="flex items-center gap-2 transition-all duration-300 hover:scale-105 data-[state=active]:bg-primary data-[state=active]:text-white">
              <ShoppingCart className="h-4 w-4" />
              Orders
            </TabsTrigger>
          </TabsList>

          {/* Products Tab */}
          <TabsContent value="products" className="animate-in slide-in-from-right-4 duration-500">
            <Card className="animate-in zoom-in duration-500 delay-100">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Product Management</CardTitle>
                  <CardDescription>Manage your security products and inventory</CardDescription>
                </div>
                <Dialog open={isProductDialogOpen} onOpenChange={setIsProductDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => {
                      setEditingProduct(null);
                      productForm.reset();
                    }}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Product
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>
                        {editingProduct ? 'Edit Product' : 'Add New Product'}
                      </DialogTitle>
                      <DialogDescription>
                        {editingProduct ? 'Update product information' : 'Add a new product to your catalog'}
                      </DialogDescription>
                    </DialogHeader>
                    <Form {...productForm}>
                      <form onSubmit={productForm.handleSubmit(handleProductSubmit)} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={productForm.control}
                            name="name"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Product Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Ultra HD CCTV System" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={productForm.control}
                            name="price"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Price ($)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    step="0.01" 
                                    placeholder="499.99" 
                                    {...field}
                                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        <FormField
                          control={productForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Complete security solution with advanced features..."
                                  className="min-h-[100px]"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={productForm.control}
                            name="category"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Category</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value}>
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select category" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="cctv">CCTV</SelectItem>
                                    <SelectItem value="alarm">Alarm</SelectItem>
                                    <SelectItem value="access">Access Control</SelectItem>
                                    <SelectItem value="smart">Smart Security</SelectItem>
                                    <SelectItem value="commercial">Commercial</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={productForm.control}
                            name="rating"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Rating (0-5)</FormLabel>
                                <FormControl>
                                  <Input 
                                    type="number" 
                                    step="0.1" 
                                    min="0" 
                                    max="5" 
                                    placeholder="4.5" 
                                    {...field}
                                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        <FormField
                          control={productForm.control}
                          name="imageUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Image URL</FormLabel>
                              <FormControl>
                                <Input placeholder="/assets/product-image.jpg" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={productForm.control}
                          name="features"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Features (comma-separated)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="4K Resolution, Night Vision, Weatherproof, Motion Detection"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <DialogFooter>
                          <Button type="submit" disabled={createProductMutation.isPending || updateProductMutation.isPending}>
                            {editingProduct ? 'Update Product' : 'Create Product'}
                          </Button>
                        </DialogFooter>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                {productsLoading ? (
                  <p>Loading products...</p>
                ) : (
                  <div className="space-y-4">
                    {(products as Product[]).map((product: Product, index) => (
                      <div 
                        key={product.id} 
                        className="flex items-center justify-between p-4 border rounded-lg transition-all duration-300 hover:shadow-md hover:scale-[1.02] animate-in slide-in-from-left-4"
                        style={{ animationDelay: `${index * 100}ms` }}
                      >
                        <div className="flex-1">
                          <h3 className="font-semibold">{product.name}</h3>
                          <p className="text-sm text-gray-600">{product.description}</p>
                          <div className="flex items-center gap-4 mt-2">
                            <span className="font-bold text-green-600">${product.price}</span>
                            <Badge variant="secondary">{product.category}</Badge>
                            <span className="text-sm text-gray-500">Rating: {product.rating}/5</span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={() => handleEditProduct(product)}
                            className="transition-all duration-200 hover:scale-110 hover:bg-blue-50"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="destructive" 
                            onClick={() => handleDeleteProduct(product.id)}
                            disabled={deleteProductMutation.isPending}
                            className="transition-all duration-200 hover:scale-110"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Contacts Tab */}
          <TabsContent value="contacts" className="animate-in slide-in-from-right-4 duration-500">
            <Card className="animate-in zoom-in duration-500 delay-100">
              <CardHeader>
                <CardTitle>Contact Submissions</CardTitle>
                <CardDescription>View and manage customer inquiries</CardDescription>
              </CardHeader>
              <CardContent>
                {contactsLoading ? (
                  <p>Loading contacts...</p>
                ) : (contacts as ContactSubmission[]).length === 0 ? (
                  <p className="text-gray-500">No contact submissions yet.</p>
                ) : (
                  <div className="space-y-4">
                    {(contacts as ContactSubmission[]).map((contact: ContactSubmission) => (
                      <div key={contact.id} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-semibold">{contact.name}</h3>
                            <p className="text-sm text-gray-600">{contact.email} • {contact.phone}</p>
                          </div>
                          <span className="text-xs text-gray-500">
                            {new Date(contact.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="mb-2">
                          <Badge variant="outline">{contact.service}</Badge>
                        </div>
                        <p className="text-sm">{contact.message}</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders" className="animate-in slide-in-from-right-4 duration-500">
            <Card className="animate-in zoom-in duration-500 delay-100">
              <CardHeader>
                <CardTitle>Customer Orders</CardTitle>
                <CardDescription>Track and manage customer orders</CardDescription>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <p>Loading orders...</p>
                ) : (orders as CustomerOrder[]).length === 0 ? (
                  <p className="text-gray-500">No orders yet.</p>
                ) : (
                  <div className="space-y-4">
                    {(orders as CustomerOrder[]).map((order: CustomerOrder) => (
                      <div key={order.id} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="font-semibold">Order #{order.id}</h3>
                            <p className="text-sm text-gray-600">{order.customerName} • {order.customerEmail}</p>
                            <p className="text-sm text-gray-600">{order.customerPhone}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-green-600">${order.totalAmount}</p>
                            <p className="text-xs text-gray-500">
                              {new Date(order.orderDate).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        
                        <div className="mb-3">
                          <p className="font-medium">{order.productName}</p>
                          <p className="text-sm text-gray-600">Quantity: {order.quantity}</p>
                          <p className="text-sm text-gray-600">Delivery: {order.deliveryAddress}</p>
                          {order.notes && (
                            <p className="text-sm text-gray-600">Notes: {order.notes}</p>
                          )}
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <Badge 
                            variant={order.status === 'completed' ? 'default' : 'secondary'}
                            className={`
                              ${order.status === 'pending' ? 'bg-orange-100 text-orange-800' : ''}
                              ${order.status === 'confirmed' ? 'bg-blue-100 text-blue-800' : ''}
                              ${order.status === 'completed' ? 'bg-green-100 text-green-800' : ''}
                              ${order.status === 'cancelled' ? 'bg-red-100 text-red-800' : ''}
                            `}
                          >
                            {order.status}
                          </Badge>
                          
                          <Select
                            value={order.status}
                            onValueChange={(status) => handleUpdateOrderStatus(order.id, status)}
                            disabled={updateOrderStatusMutation.isPending}
                          >
                            <SelectTrigger className="w-40">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="pending">Pending</SelectItem>
                              <SelectItem value="confirmed">Confirmed</SelectItem>
                              <SelectItem value="completed">Completed</SelectItem>
                              <SelectItem value="cancelled">Cancelled</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function Admin() {
  return (
    <ProtectedRoute>
      <AdminContent />
    </ProtectedRoute>
  );
}
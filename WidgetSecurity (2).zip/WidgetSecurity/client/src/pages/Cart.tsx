import { useState } from "react";
import { useCart } from "@/context/CartContext";
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft, CreditCard, CheckCircle } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import PaymentGateway from "@/components/ui/payment-gateway";

type CheckoutForm = {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  deliveryAddress: string;
  notes?: string;
};

export default function Cart() {
  const { items, removeFromCart, updateQuantity, clearCart, getTotalItems, getTotalPrice } = useCart();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [checkoutData, setCheckoutData] = useState<CheckoutForm | null>(null);

  const { register, handleSubmit, formState: { errors }, reset } = useForm<CheckoutForm>();

  const handleQuantityChange = (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    updateQuantity(productId, newQuantity);
  };

  const handleCheckoutSubmit = async (data: CheckoutForm) => {
    setCheckoutData(data);
    setShowPayment(true);
  };

  const handlePaymentSuccess = async (paymentData: any) => {
    setIsCheckingOut(true);
    
    try {
      // Create orders for each item in cart
      for (const item of items) {
        const orderData = {
          customerName: checkoutData!.customerName,
          customerEmail: checkoutData!.customerEmail,
          customerPhone: checkoutData!.customerPhone,
          productId: item.product.id,
          productName: item.product.name,
          quantity: item.quantity,
          totalAmount: item.product.price * item.quantity,
          status: "paid",
          deliveryAddress: checkoutData!.deliveryAddress,
          notes: checkoutData!.notes || "",
          paymentMethod: paymentData.method,
          transactionId: paymentData.transactionId
        };

        const response = await fetch('/api/admin/orders', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(orderData)
        });

        if (!response.ok) {
          throw new Error('Failed to create order');
        }
      }

      toast({
        title: "Payment Successful! 🎉",
        description: `Your order for ${getTotalItems()} items has been placed. Transaction ID: ${paymentData.transactionId}`,
      });

      clearCart();
      reset();
      setShowPayment(false);
      setCheckoutData(null);
      setLocation("/");
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to place order. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsCheckingOut(false);
    }
  };

  const handlePaymentError = (error: string) => {
    toast({
      title: "Payment Failed",
      description: error,
      variant: "destructive"
    });
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 animate-fade-in">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center animate-slide-in-up">
            <ShoppingBag className="h-20 w-20 mx-auto text-gray-400 mb-4" />
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Cart is Empty</h1>
            <p className="text-gray-600 mb-8">Add some security products to get started!</p>
            <Link href="/products">
              <button className="apple-button">
                Browse Products
              </button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (showPayment) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 animate-fade-in">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <Link href="/cart">
                <button className="flex items-center text-blue-600 hover:text-blue-800 transition-colors mb-4">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Cart
                </button>
              </Link>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Complete Your Purchase</h1>
              <p className="text-gray-600">Secure payment processing</p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {/* Order Summary */}
              <div className="bg-white rounded-2xl shadow-xl p-6 animate-scale-in">
                <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
                <div className="space-y-4">
                  {items.map((item) => (
                    <div key={item.product.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <img 
                          src={item.product.imageUrl} 
                          alt={item.product.name}
                          className="h-12 w-12 object-cover rounded-lg mr-3"
                        />
                        <div>
                          <h3 className="font-medium text-gray-800">{item.product.name}</h3>
                          <p className="text-sm text-gray-600">Qty: {item.quantity}</p>
                        </div>
                      </div>
                      <span className="font-semibold text-blue-600">${(item.product.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                <div className="border-t border-gray-200 pt-4 mt-4">
                  <div className="flex justify-between items-center text-lg font-semibold">
                    <span>Total</span>
                    <span className="text-blue-600">${getTotalPrice().toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Payment Gateway */}
              <PaymentGateway 
                amount={getTotalPrice()}
                onPaymentSuccess={handlePaymentSuccess}
                onPaymentError={handlePaymentError}
              />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 animate-fade-in">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 animate-slide-in-up">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Shopping Cart</h1>
            <p className="text-gray-600">Review your items and proceed to checkout</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-2xl shadow-xl p-6 animate-scale-in">
                <h2 className="text-xl font-semibold mb-6">Cart Items ({getTotalItems()})</h2>
                <div className="space-y-4">
                  {items.map((item) => (
                    <div key={item.product.id} className="apple-card hover-lift">
                      <div className="flex items-center">
                        <img 
                          src={item.product.imageUrl} 
                          alt={item.product.name}
                          className="h-16 w-16 object-cover rounded-lg mr-4"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-800">{item.product.name}</h3>
                          <p className="text-sm text-gray-600">${item.product.price.toFixed(2)} each</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleQuantityChange(item.product.id, item.quantity - 1)}
                            className="p-1 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                          <span className="w-8 text-center font-medium">{item.quantity}</span>
                          <button
                            onClick={() => handleQuantityChange(item.product.id, item.quantity + 1)}
                            className="p-1 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>
                        <div className="text-right ml-4">
                          <span className="font-semibold text-blue-600">${(item.product.price * item.quantity).toFixed(2)}</span>
                          <button
                            onClick={() => removeFromCart(item.product.id)}
                            className="block mt-1 text-red-500 hover:text-red-700 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Checkout Form */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl shadow-xl p-6 animate-scale-in">
                <h2 className="text-xl font-semibold mb-6">Checkout Information</h2>
                <form onSubmit={handleSubmit(handleCheckoutSubmit)} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                    <input
                      {...register("customerName", { required: "Name is required" })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                      placeholder="John Doe"
                    />
                    {errors.customerName && (
                      <p className="text-red-500 text-sm mt-1">{errors.customerName.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input
                      {...register("customerEmail", { 
                        required: "Email is required",
                        pattern: {
                          value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                          message: "Invalid email address"
                        }
                      })}
                      type="email"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                      placeholder="john@example.com"
                    />
                    {errors.customerEmail && (
                      <p className="text-red-500 text-sm mt-1">{errors.customerEmail.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                    <input
                      {...register("customerPhone", { required: "Phone is required" })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                      placeholder="+1 (555) 123-4567"
                    />
                    {errors.customerPhone && (
                      <p className="text-red-500 text-sm mt-1">{errors.customerPhone.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Delivery Address</label>
                    <textarea
                      {...register("deliveryAddress", { required: "Address is required" })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                      rows={3}
                      placeholder="123 Main St, City, State 12345"
                    />
                    {errors.deliveryAddress && (
                      <p className="text-red-500 text-sm mt-1">{errors.deliveryAddress.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Notes (Optional)</label>
                    <textarea
                      {...register("notes")}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                      rows={2}
                      placeholder="Special instructions..."
                    />
                  </div>

                  <div className="border-t border-gray-200 pt-4">
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-lg font-medium">Total</span>
                      <span className="text-2xl font-bold text-blue-600">${getTotalPrice().toFixed(2)}</span>
                    </div>
                    
                    <button
                      type="submit"
                      disabled={isCheckingOut}
                      className="w-full apple-button flex items-center justify-center"
                    >
                      {isCheckingOut ? (
                        <>
                          <div className="loading-spinner mr-3"></div>
                          Processing...
                        </>
                      ) : (
                        <>
                          <CreditCard className="h-5 w-5 mr-2" />
                          Proceed to Payment
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
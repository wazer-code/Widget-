import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { contactFormSchema, type ContactFormData } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Building2, 
  Home, 
  Shield,
  Building,
  ShieldCheck
} from "lucide-react";
import { FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram } from "react-icons/fa";

const Contact = () => {
  const { toast } = useToast();
  
  const form = useForm<ContactFormData>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      service: "",
      message: "",
      termsAccepted: false
    }
  });
  
  const contactMutation = useMutation({
    mutationFn: (data: ContactFormData) => {
      return apiRequest("POST", "/api/contact", data);
    },
    onSuccess: async () => {
      toast({
        title: "Success!",
        description: "Your message has been sent. We'll get back to you soon.",
        variant: "default",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "There was a problem submitting the form. Please try again.",
        variant: "destructive",
      });
      console.error(error);
    }
  });
  
  const onSubmit = (data: ContactFormData) => {
    contactMutation.mutate(data);
  };

  return (
    <div className="container mx-auto px-4 py-16 page-transition">
      {/* Page Header */}
      <div className="text-center mb-16">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 font-heading">Contact Widget Security</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Have questions about our security systems or services? Get in touch with our team today.
          We're here to help you find the perfect security solution.
        </p>
      </div>

      {/* Contact Information and Form */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Contact Information */}
        <div>
          <div className="bg-white rounded-lg shadow-md p-8 mb-8">
            <h2 className="text-2xl font-bold mb-6 font-heading">Get In Touch</h2>
            
            <div className="space-y-6 mb-8">
              <div className="flex items-start">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                  <MapPin className="text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Our Location</h3>
                  <p className="text-gray-600">123 Security Ave, Safetown, ST 12345</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                  <Phone className="text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Phone Numbers</h3>
                  <p className="text-gray-600">Main: (123) 456-7890</p>
                  <p className="text-gray-600">Support: (123) 456-7891</p>
                  <p className="text-gray-600">Emergency: (123) 456-7899</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                  <Mail className="text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Email Addresses</h3>
                  <p className="text-gray-600">General Inquiries: info@widgetsecurity.com</p>
                  <p className="text-gray-600">Support: support@widgetsecurity.com</p>
                  <p className="text-gray-600">Sales: sales@widgetsecurity.com</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mr-4">
                  <Clock className="text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-1">Business Hours</h3>
                  <p className="text-gray-600">Monday - Friday: 8:00 AM - 6:00 PM</p>
                  <p className="text-gray-600">Saturday: 9:00 AM - 3:00 PM</p>
                  <p className="text-gray-600">Sunday: Closed</p>
                  <p className="text-gray-600 font-medium mt-2">24/7 Emergency Support Available</p>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-primary hover:bg-secondary text-white rounded-full flex items-center justify-center transition-colors">
                <FaFacebookF />
              </a>
              <a href="#" className="w-10 h-10 bg-primary hover:bg-secondary text-white rounded-full flex items-center justify-center transition-colors">
                <FaTwitter />
              </a>
              <a href="#" className="w-10 h-10 bg-primary hover:bg-secondary text-white rounded-full flex items-center justify-center transition-colors">
                <FaLinkedinIn />
              </a>
              <a href="#" className="w-10 h-10 bg-primary hover:bg-secondary text-white rounded-full flex items-center justify-center transition-colors">
                <FaInstagram />
              </a>
            </div>
          </div>
          
          {/* Custom Security Solutions */}
          <div className="bg-gray-50 rounded-lg p-6 shadow-sm">
            <h3 className="text-xl font-bold mb-4 font-heading">Security Solutions For:</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-start">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                  <Home className="text-primary h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Homes</h4>
                  <p className="text-gray-600 text-sm">Protect your family and property</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                  <Building2 className="text-primary h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Businesses</h4>
                  <p className="text-gray-600 text-sm">Secure your company assets</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                  <Building className="text-primary h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Commercial</h4>
                  <p className="text-gray-600 text-sm">Solutions for large facilities</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                  <ShieldCheck className="text-primary h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Customized</h4>
                  <p className="text-gray-600 text-sm">Tailored to your needs</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Contact Form */}
        <div>
          <div className="bg-white rounded-lg shadow-md p-8">
            <div className="flex items-center mb-6">
              <Shield className="h-6 w-6 text-primary mr-2" />
              <h2 className="text-2xl font-bold font-heading">Request a Quote</h2>
            </div>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="john@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="(123) 456-7890" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="service"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Service Interest</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a service" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="cctv">CCTV Systems</SelectItem>
                            <SelectItem value="alarm">Alarm Systems</SelectItem>
                            <SelectItem value="access">Access Control</SelectItem>
                            <SelectItem value="smart">Smart Security</SelectItem>
                            <SelectItem value="monitoring">24/7 Monitoring</SelectItem>
                            <SelectItem value="maintenance">Maintenance</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell us about your security needs..." 
                          rows={5} 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="termsAccepted"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          I agree to the <a href="#" className="text-primary hover:underline">terms and conditions</a>
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={contactMutation.isPending}
                >
                  {contactMutation.isPending ? "Submitting..." : "Submit Request"}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>

      {/* Map Section */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6 font-heading text-center">Visit Our Office</h2>
        <div className="bg-gray-100 rounded-lg overflow-hidden shadow-md h-96">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.9663095343008!2d-74.00425882426296!3d40.71256623880885!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a1671a4a5bf%3A0x14442e81d4b8b251!2sBroadway%2C%20New%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sus!4v1683924565148!5m2!1sen!2sus" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen={false} 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            title="Widget Security Office Location"
          ></iframe>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-8 font-heading text-center">Frequently Asked Contact Questions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white border border-gray-200 p-6 rounded-lg">
            <h3 className="text-lg font-bold mb-3">How quickly will I receive a response?</h3>
            <p className="text-gray-600">
              We strive to respond to all inquiries within 24 business hours. For urgent matters, 
              we recommend calling our direct line at (123) 456-7890.
            </p>
          </div>
          
          <div className="bg-white border border-gray-200 p-6 rounded-lg">
            <h3 className="text-lg font-bold mb-3">Can I schedule a consultation outside business hours?</h3>
            <p className="text-gray-600">
              Yes, we offer flexible scheduling and can arrange consultations during evenings and 
              weekends to accommodate your schedule. Please mention your preferred time in the message.
            </p>
          </div>
          
          <div className="bg-white border border-gray-200 p-6 rounded-lg">
            <h3 className="text-lg font-bold mb-3">Do you offer virtual consultations?</h3>
            <p className="text-gray-600">
              Yes, we offer virtual consultations via video call. This allows us to provide initial 
              guidance and recommendations before an in-person assessment.
            </p>
          </div>
          
          <div className="bg-white border border-gray-200 p-6 rounded-lg">
            <h3 className="text-lg font-bold mb-3">Is there a fee for a security assessment?</h3>
            <p className="text-gray-600">
              We provide free initial consultations and security assessments as part of our commitment 
              to helping you find the right security solution for your needs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;

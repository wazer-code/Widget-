import Hero from "@/components/home/Hero";
import Features from "@/components/home/Features";
import ProductsSection from "@/components/home/ProductsSection";
import ServicesSection from "@/components/home/ServicesSection";
import Testimonials from "@/components/home/Testimonials";
import InstallationGallery from "@/components/home/InstallationGallery";
import ContactSection from "@/components/home/ContactSection";
import FAQ from "@/components/home/FAQ";
import CTA from "@/components/home/CTA";

const Home = () => {
  return (
    <main>
      <Hero />
      <Features />
      <ProductsSection />
      <ServicesSection />
      <Testimonials />
      <InstallationGallery />
      <ContactSection />
      <FAQ />
      <CTA />
    </main>
  );
};

export default Home;

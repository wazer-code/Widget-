import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Product } from "@shared/schema";
import { 
  ArrowLeft, 
  Shield, 
  Star, 
  StarHalf, 
  ShoppingCart, 
  Heart, 
  Share2 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";

const ProductDetails = () => {
  const { id } = useParams();
  const { toast } = useToast();
  
  const { data: product, isLoading, isError } = useQuery({
    queryKey: [`/api/products/${id}`],
  });
  
  const renderRatingStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="fill-amber-500 text-amber-500" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="fill-amber-500 text-amber-500" />);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-amber-500" />);
    }

    return stars;
  };
  
  const handleAddToCart = () => {
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };
  
  const handleAddToWishlist = () => {
    toast({
      title: "Added to wishlist",
      description: `${product.name} has been added to your wishlist.`,
    });
  };
  
  if (isError) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <Shield className="h-16 w-16 text-red-500 mx-auto mb-4" />
        <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
        <p className="mb-8">Sorry, we couldn't find the product you're looking for.</p>
        <Link href="/products">
          <Button>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Products
          </Button>
        </Link>
      </div>
    );
  }
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <Skeleton className="w-full aspect-square rounded-md" />
          <div className="space-y-6">
            <Skeleton className="h-10 w-3/4" />
            <div className="flex items-center space-x-2">
              <Skeleton className="h-5 w-24" />
              <Skeleton className="h-5 w-24" />
            </div>
            <Skeleton className="h-6 w-32" />
            <div className="space-y-3">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
            <div className="flex flex-wrap gap-2">
              <Skeleton className="h-6 w-20" />
              <Skeleton className="h-6 w-20" />
              <Skeleton className="h-6 w-20" />
            </div>
            <div className="flex gap-4">
              <Skeleton className="h-11 w-40" />
              <Skeleton className="h-11 w-11" />
              <Skeleton className="h-11 w-11" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-6">
        <Link href="/products">
          <Button variant="ghost" className="pl-0">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Products
          </Button>
        </Link>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div>
          <div className="bg-gray-100 rounded-lg overflow-hidden mb-4">
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-full h-auto object-cover"
            />
          </div>
        </div>
        
        <div>
          <h1 className="text-3xl font-bold mb-4 font-heading">{product.name}</h1>
          
          <div className="flex items-center space-x-4 mb-4">
            <div className="flex">
              {renderRatingStars(product.rating)}
            </div>
            <span className="text-gray-500">{product.rating} out of 5</span>
          </div>
          
          <div className="text-2xl font-bold text-primary mb-6">
            ${product.price.toFixed(2)}
          </div>
          
          <p className="text-gray-700 mb-6">{product.description}</p>
          
          <div className="flex flex-wrap gap-2 mb-6">
            {product.features.map((feature, index) => (
              <Badge key={index} variant="secondary" className="bg-gray-100 text-gray-700">
                {feature}
              </Badge>
            ))}
          </div>
          
          <div className="flex gap-4 mb-8">
            <Button size="lg" onClick={handleAddToCart}>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to Cart
            </Button>
            <Button variant="outline" size="icon" onClick={handleAddToWishlist}>
              <Heart className="h-5 w-5" />
            </Button>
            <Button variant="outline" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
          
          <Separator className="my-6" />
          
          <div>
            <h3 className="font-semibold mb-2">Shipping</h3>
            <p className="text-gray-600 mb-4">Free shipping on orders over $100. Standard delivery 3-5 business days.</p>
            
            <h3 className="font-semibold mb-2">Returns</h3>
            <p className="text-gray-600">30-day return policy. See our <Link href="/terms" className="text-primary hover:underline">return policy</Link> for more details.</p>
          </div>
        </div>
      </div>
      
      <div className="mt-16">
        <Tabs defaultValue="details">
          <TabsList className="w-full justify-start border-b mb-6 rounded-none bg-transparent">
            <TabsTrigger value="details" className="text-lg data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
              Product Details
            </TabsTrigger>
            <TabsTrigger value="specifications" className="text-lg data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
              Specifications
            </TabsTrigger>
            <TabsTrigger value="warranty" className="text-lg data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
              Warranty
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="details">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4 font-heading">Key Features</h3>
                <ul className="space-y-2 list-disc list-inside text-gray-700">
                  <li>Advanced motion detection with AI recognition</li>
                  <li>Weatherproof and durable construction</li>
                  <li>Easy integration with existing systems</li>
                  <li>Remote access via smartphone application</li>
                  <li>Night vision capabilities up to 30 feet</li>
                  <li>Two-way audio communication</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4 font-heading">What's Included</h3>
                <ul className="space-y-2 list-disc list-inside text-gray-700">
                  <li>{product.name}</li>
                  <li>Mounting bracket and hardware</li>
                  <li>Power adapter</li>
                  <li>Quick start guide</li>
                  <li>User manual</li>
                </ul>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="specifications">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4 font-heading">Technical Specifications</h3>
                <div className="space-y-2">
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Resolution</span>
                    <span>4K Ultra HD (3840 x 2160)</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Field of View</span>
                    <span>130° Diagonal</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Night Vision</span>
                    <span>Up to 30 ft (9 m)</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Audio</span>
                    <span>Two-way with noise cancellation</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Connectivity</span>
                    <span>Wi-Fi 802.11 b/g/n/ac (2.4GHz/5GHz)</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Power</span>
                    <span>AC Power / Battery Backup</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4 font-heading">Dimensions & Weight</h3>
                <div className="space-y-2">
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Dimensions</span>
                    <span>70 x 70 x 100 mm (2.8 x 2.8 x 3.9 in)</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Weight</span>
                    <span>365 g (12.9 oz)</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Operating Temperature</span>
                    <span>-20°C to 45°C (-4°F to 113°F)</span>
                  </div>
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Weatherproof Rating</span>
                    <span>IP65</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="warranty">
            <div>
              <h3 className="text-xl font-bold mb-4 font-heading">Warranty Information</h3>
              <p className="mb-4">All Widget security products come with a standard 2-year limited warranty. Our warranty covers defects in materials and workmanship under normal use.</p>
              
              <div className="bg-gray-50 p-6 rounded-lg mb-6">
                <h4 className="font-bold mb-2">What's Covered</h4>
                <ul className="space-y-2 list-disc list-inside text-gray-700 mb-4">
                  <li>Manufacturing defects</li>
                  <li>Hardware failures not caused by accidents or misuse</li>
                  <li>Software issues related to normal operation</li>
                </ul>
                
                <h4 className="font-bold mb-2">What's Not Covered</h4>
                <ul className="space-y-2 list-disc list-inside text-gray-700">
                  <li>Damage from accidents, misuse, or natural disasters</li>
                  <li>Unauthorized modifications or repairs</li>
                  <li>Normal wear and tear</li>
                  <li>Theft or loss of the product</li>
                </ul>
              </div>
              
              <p className="mb-4">Extended warranty plans are available for purchase, providing coverage for up to 5 years from the date of purchase.</p>
              
              <p className="text-primary font-medium">For warranty claims or questions, please contact our customer support team at (123) 456-7890 or support@widgetsecurity.com</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ProductDetails;

import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Product } from "@shared/schema";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Heart, Star, StarHalf, Filter } from "lucide-react";
import { useProductCategory } from "@/hooks/useProductCategory";

const ProductCard = ({ product }: { product: Product }) => {
  const renderRatingStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="fill-amber-500 text-amber-500" />);
    }

    if (hasHalfStar) {
      stars.push(<StarHalf key="half-star" className="fill-amber-500 text-amber-500" />);
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-amber-500" />);
    }

    return stars;
  };

  return (
    <Card className="overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      <div className="h-48 overflow-hidden">
        <img
          src={product.imageUrl}
          alt={product.name}
          className="w-full h-full object-cover"
        />
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-bold mb-2 font-heading">{product.name}</h3>
        <div className="flex justify-between mb-4">
          <span className="text-primary font-semibold">${product.price.toFixed(2)}</span>
          <div className="flex">
            {renderRatingStars(product.rating)}
          </div>
        </div>
        <p className="text-gray-600 mb-4">{product.description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {product.features.map((feature, index) => (
            <Badge key={index} variant="secondary" className="bg-gray-100 text-gray-600 hover:bg-gray-200">
              {feature}
            </Badge>
          ))}
        </div>
      </CardContent>
      <CardFooter className="p-6 pt-0 flex space-x-2">
        <Link href={`/products/${product.id}`} className="flex-1">
          <Button className="w-full">View Details</Button>
        </Link>
        <Button variant="outline" size="icon" className="bg-gray-100 hover:bg-gray-200">
          <Heart className="h-4 w-4 text-gray-400 hover:text-red-500" />
        </Button>
      </CardFooter>
    </Card>
  );
};

const ProductSkeleton = () => (
  <Card className="overflow-hidden">
    <Skeleton className="h-48 w-full" />
    <CardContent className="p-6">
      <Skeleton className="h-6 w-3/4 mb-2" />
      <div className="flex justify-between mb-4">
        <Skeleton className="h-4 w-20" />
        <Skeleton className="h-4 w-24" />
      </div>
      <Skeleton className="h-4 w-full mb-2" />
      <Skeleton className="h-4 w-full mb-2" />
      <Skeleton className="h-4 w-2/3 mb-4" />
      <div className="flex flex-wrap gap-2 mb-4">
        <Skeleton className="h-6 w-20" />
        <Skeleton className="h-6 w-24" />
        <Skeleton className="h-6 w-16" />
      </div>
    </CardContent>
    <CardFooter className="p-6 pt-0 flex space-x-2">
      <Skeleton className="h-10 w-full" />
      <Skeleton className="h-10 w-10" />
    </CardFooter>
  </Card>
);

const Products = () => {
  const [location] = useLocation();
  const { category, setCategory, sortOption, setSortOption } = useProductCategory();
  
  const { data: products, isLoading } = useQuery({
    queryKey: ['/api/products'],
  });
  
  useEffect(() => {
    // Get category from URL query params if present
    const params = new URLSearchParams(location.split('?')[1]);
    const categoryParam = params.get('category');
    if (categoryParam) {
      setCategory(categoryParam);
    }
  }, [location, setCategory]);
  
  const categories = [
    { id: 'all', name: 'All Products' },
    { id: 'cctv', name: 'CCTV Systems' },
    { id: 'alarm', name: 'Alarm Systems' },
    { id: 'access', name: 'Access Control' },
    { id: 'smart', name: 'Smart Security' },
  ];
  
  const sortOptions = [
    { value: 'latest', label: 'Latest' },
    { value: 'price-low', label: 'Price: Low to High' },
    { value: 'price-high', label: 'Price: High to Low' },
    { value: 'rating', label: 'Top Rated' },
  ];
  
  // Filter products by category
  const filteredProducts = (products as Product[] || [])
    ? category === 'all'
      ? [...(products as Product[])]
      : (products as Product[]).filter((product: Product) => product.category === category)
    : [];
  
  // Sort products
  const sortedProducts = [...filteredProducts];
  switch (sortOption) {
    case 'price-low':
      sortedProducts.sort((a, b) => a.price - b.price);
      break;
    case 'price-high':
      sortedProducts.sort((a, b) => b.price - a.price);
      break;
    case 'rating':
      sortedProducts.sort((a, b) => b.rating - a.rating);
      break;
    default:
      // 'latest' or any other, keep original order
      break;
  }
  
  return (
    <div className="container mx-auto px-4 py-16 page-transition">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4 font-heading">Security Products</h1>
          <p className="text-lg text-gray-600 max-w-2xl">
            Browse our comprehensive range of security solutions designed for your peace of mind.
          </p>
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row gap-8 mb-10">
        <div className="w-full md:w-64 flex-shrink-0">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center mb-4">
              <Filter className="h-5 w-5 mr-2" />
              <h2 className="text-lg font-bold">Filters</h2>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium mb-3">Product Categories</h3>
              <div className="space-y-2">
                {categories.map((cat) => (
                  <div key={cat.id} className="flex items-center">
                    <input
                      type="radio"
                      id={`cat-${cat.id}`}
                      name="category"
                      checked={category === cat.id}
                      onChange={() => setCategory(cat.id)}
                      className="mr-2"
                    />
                    <label htmlFor={`cat-${cat.id}`} className="text-gray-700 cursor-pointer">
                      {cat.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="font-medium mb-3">Sort By</h3>
              <Select value={sortOption} onValueChange={setSortOption}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        <div className="flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {isLoading
              ? Array(6)
                  .fill(0)
                  .map((_, index) => <ProductSkeleton key={index} />)
              : sortedProducts.map((product: Product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
          </div>
          
          {!isLoading && sortedProducts.length === 0 && (
            <div className="text-center py-16">
              <h3 className="text-xl font-medium mb-2">No Products Found</h3>
              <p className="text-gray-500 mb-6">
                We couldn't find any products that match your current filters.
              </p>
              <Button onClick={() => setCategory('all')}>
                View All Products
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Products;

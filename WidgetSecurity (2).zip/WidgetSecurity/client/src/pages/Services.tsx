import { useQuery } from "@tanstack/react-query";
import { Service } from "@shared/schema";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const ServiceCard = ({ service }: { service: Service }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow">
      <div className="p-1 bg-primary"></div>
      <div className="p-6">
        <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mb-4">
          <i className={`fas ${service.icon} text-primary text-2xl`}></i>
        </div>
        <h3 className="text-xl font-bold mb-3 font-heading">{service.name}</h3>
        <p className="text-gray-600 mb-4">
          {service.description}
        </p>
        <ul className="space-y-2 mb-6">
          {service.benefits.map((benefit, index) => (
            <li key={index} className="flex items-start">
              <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
              <span>{benefit}</span>
            </li>
          ))}
        </ul>
        <a href="#" className="text-primary hover:text-secondary font-medium inline-flex items-center">
          Learn More <ArrowRight className="ml-2 h-4 w-4" />
        </a>
      </div>
    </div>
  );
};

const ServiceSkeleton = () => (
  <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-md">
    <div className="p-1 bg-gray-300"></div>
    <div className="p-6">
      <Skeleton className="w-14 h-14 rounded-full mb-4" />
      <Skeleton className="h-7 w-1/2 mb-3" />
      <Skeleton className="h-4 w-full mb-2" />
      <Skeleton className="h-4 w-full mb-2" />
      <Skeleton className="h-4 w-2/3 mb-4" />
      <div className="space-y-2 mb-6">
        <div className="flex items-start">
          <Skeleton className="h-4 w-4 mt-1 mr-2" />
          <Skeleton className="h-4 w-5/6" />
        </div>
        <div className="flex items-start">
          <Skeleton className="h-4 w-4 mt-1 mr-2" />
          <Skeleton className="h-4 w-3/4" />
        </div>
        <div className="flex items-start">
          <Skeleton className="h-4 w-4 mt-1 mr-2" />
          <Skeleton className="h-4 w-4/5" />
        </div>
      </div>
      <Skeleton className="h-5 w-28" />
    </div>
  </div>
);

const Services = () => {
  const { data: services, isLoading } = useQuery({
    queryKey: ['/api/services'],
  });

  return (
    <div className="container mx-auto px-4 py-16 page-transition">
      <div className="text-center mb-16">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 font-heading">Our Security Services</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          At Widget, we offer comprehensive security services to ensure your home or business is protected around the clock.
          Our expert team provides installation, monitoring, maintenance, and much more.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        {isLoading
          ? Array(6)
              .fill(0)
              .map((_, index) => <ServiceSkeleton key={index} />)
          : (services as Service[] || []).map((service: Service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
      </div>
      
      <div className="bg-gray-50 rounded-lg p-8 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-2xl font-bold mb-4 font-heading">Custom Security Solutions</h2>
            <p className="text-gray-600 mb-6">
              Need a tailored security solution for your specific requirements? Our security experts can design a custom system that perfectly meets your needs and budget. We provide personalized consultations to assess your security needs and recommend the ideal combination of products and services.
            </p>
            <ul className="space-y-2 mb-6">
              <li className="flex items-start">
                <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                <span>Personalized security assessment</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                <span>Custom system design and planning</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                <span>Flexible pricing options and packages</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="text-green-500 mt-1 mr-2 h-4 w-4" />
                <span>Professional installation and training</span>
              </li>
            </ul>
            <Link href="/contact">
              <Button>Schedule a Consultation</Button>
            </Link>
          </div>
          <div className="hidden md:block">
            <img 
              src="https://images.unsplash.com/photo-1573167374727-553965282e67?auto=format&fit=crop&w=600&h=400" 
              alt="Security Consultation" 
              className="rounded-lg shadow-md"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;

#!/bin/bash

# Create a temporary directory for the optimized project
mkdir -p optimized_project

# Copy essential files and directories, excluding node_modules and other large directories
echo "Copying essential project files..."
cp -r client server shared netlify *.json *.js *.ts optimized_project/
mkdir -p optimized_project/attached_assets
mkdir -p optimized_project/public/assets

# Copy and optimize images - only to public/assets to avoid duplication
echo "Optimizing images..."
for img in attached_assets/*.jpeg attached_assets/*.png; do
  if [ -f "$img" ]; then
    echo "Optimizing $img"
    # Only copy to public/assets for static serving
    convert "$img" -quality 65 -resize 75% "optimized_project/public/assets/$(basename $img)"
  fi
done

# Remove the empty attached_assets directory since we're not using it
rm -rf optimized_project/attached_assets

# Update server/index.ts to use only public/assets
if [ -f "optimized_project/server/index.ts" ]; then
  echo "Updating server/index.ts to serve assets only from public directory..."
  # Completely replace the asset serving section
  sed -i '/\/\/ Serve static files/,/console.log/c\
// Serve static files from public/assets directory\
app.use(\x27/assets\x27, express.static(path.join(process.cwd(), \x27public/assets\x27)));\
console.log(\x27Serving assets from:\x27, path.join(process.cwd(), \x27public/assets\x27));' optimized_project/server/index.ts
fi

# Remove any previous build artifacts and unnecessary files
rm -rf optimized_project/dist optimized_project/node_modules optimized_project/.cache optimized_project/.git
rm -rf optimized_project/attached_assets_backup optimized_project/optimized_assets
rm -f optimized_project/.DS_Store optimized_project/.gitignore

# Extract original package.json to get current scripts and dependencies
cp package.json optimized_project/package.json

# Create a script to clean up the package.json - using .cjs extension for CommonJS
cat > clean-package.cjs << EOF
const fs = require('fs');
const packageJson = JSON.parse(fs.readFileSync('optimized_project/package.json', 'utf8'));

// Remove devDependencies except essential ones
const essentialDevDeps = {};
['@types/express', '@types/node', '@types/react', '@types/react-dom', 
 '@vitejs/plugin-react', 'autoprefixer', 'esbuild', 'postcss', 
 'tailwindcss', 'tsx', 'typescript', 'vite'].forEach(dep => {
  if (packageJson.devDependencies && packageJson.devDependencies[dep]) {
    essentialDevDeps[dep] = packageJson.devDependencies[dep];
  }
});

packageJson.devDependencies = essentialDevDeps;

// Update engines to ensure correct Node.js version
packageJson.engines = {
  'node': '>=18.x'
};

// Make sure scripts are properly defined
if (!packageJson.scripts) {
  packageJson.scripts = {};
}

// Ensure the build script is properly configured for both Vercel and Netlify
packageJson.scripts.build = 'vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist';
packageJson.scripts.start = 'NODE_ENV=production node dist/index.js';

// Add Netlify serverless dependencies
if (!packageJson.dependencies) {
  packageJson.dependencies = {};
}
packageJson.dependencies['serverless-http'] = '^3.2.0';

fs.writeFileSync('optimized_project/package.json', JSON.stringify(packageJson, null, 2), 'utf8');
EOF

# Run the clean package script
node clean-package.cjs
rm clean-package.cjs

# Create vercel.json for deployment - using a direct approach to avoid escaping issues
echo '{
  "version": 2,
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "installCommand": "npm install",
  "builds": [
    {
      "src": "server/index.ts",
      "use": "@vercel/node"
    },
    {
      "src": "package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "dist"
      }
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "server/index.ts"
    },
    {
      "src": "/(assets|images)/.*",
      "dest": "dist/$0"
    },
    {
      "src": "/(.+\\.[a-z0-9]+)$",
      "dest": "dist/$1"
    },
    {
      "src": "/(.*)",
      "dest": "dist/index.html"
    }
  ]
}' > optimized_project/vercel.json

# Create a README with deployment instructions
cat > optimized_project/README.md << EOF
# Security Systems Website

This is a professional security systems and CCTV company website with product catalog and customer engagement tools.

## Deployment Instructions

### Netlify Deployment (Recommended)
1. Push this code to a GitHub repository
2. Connect to Netlify and select the repository
3. Set up build settings:
   - Build Command: npm run build
   - Publish Directory: dist
4. Set these environment variables:
   - NODE_ENV: production
   - PORT: 8080

### Vercel Deployment (Alternative)
1. Push this code to a GitHub repository
2. Connect to Vercel and select the repository
3. Set up build settings:
   - Build Command: npm run build
   - Output Directory: dist
4. Set these environment variables:
   - NODE_ENV: production
   - PORT: 8080

### Local Development
1. Install dependencies: npm install
2. Start development server: npm run dev
3. Build for production: npm run build
EOF

echo "Project optimized and ready for download!"
echo "Size of optimized project:"
du -sh optimized_project

# Use tar instead of zip since it's more commonly available
echo "Creating tar archive of the optimized project..."
tar -czf optimized_project.tar.gz optimized_project

echo "Archive created: optimized_project.tar.gz"
du -sh optimized_project.tar.gz

echo ""
echo "DEPLOYMENT INSTRUCTIONS:"
echo "------------------------"
echo "1. Download this archive file: optimized_project.tar.gz"
echo "2. Extract it: tar -xzf optimized_project.tar.gz"
echo "3. Navigate to the extracted directory: cd optimized_project"
echo ""
echo "For Netlify deployment (recommended):"
echo "4a. Install Netlify CLI: npm install -g netlify-cli"
echo "4b. Deploy to Netlify: netlify deploy --prod"
echo ""
echo "For Vercel deployment (alternative):"
echo "4c. Install Vercel CLI: npm install -g vercel"
echo "4d. Deploy to Vercel: vercel --prod"
echo ""
echo "Or simply upload the extracted directory to your Netlify or Vercel account through their browser interface."
// Simple server for Replit compatibility
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 5000;

// Serve static files from attached_assets
app.use('/assets', express.static(path.join(__dirname, 'attached_assets')));
console.log('Serving attached assets from:', path.join(__dirname, 'attached_assets'));

// Sample products data - hardcoded for simplicity
const products = [
  {
    id: 1,
    name: "Ultra HD CCTV System",
    description: "Complete 4K Ultra HD security camera system with night vision, motion detection, and smartphone connectivity.",
    price: 499.99,
    category: "cameras",
    features: ["4K Resolution", "Night Vision", "Weatherproof", "Motion Detection"],
    image: "/assets/IMG_0974.jpeg"
  },
  {
    id: 2,
    name: "Smart Alarm Pro",
    description: "Comprehensive alarm system with door/window sensors, motion detectors, and smart integration.",
    price: 449.99,
    category: "alarms",
    features: ["Smartphone Control", "Smart Home", "Wireless", "Sirens"],
    image: "/assets/IMG_0990.jpeg"
  },
  {
    id: 3,
    name: "Biometric Access Control",
    description: "Advanced biometric fingerprint and facial recognition system for secured access control.",
    price: 599.99,
    category: "access",
    features: ["Biometric", "Facial Recognition", "App Control", "Multi-user"],
    image: "/assets/IMG_1007.jpeg"
  }
];

// Create a simple HTML page to display the products
const generateHTML = () => {
  const productCards = products.map(product => `
    <div class="product-card">
      <img src="${product.image}" alt="${product.name}" class="product-image">
      <div class="product-info">
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <p class="product-price">$${product.price}</p>
        <div class="features">
          ${product.features.map(feature => `<span class="feature">${feature}</span>`).join('')}
        </div>
      </div>
    </div>
  `).join('');

  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Widget Security Systems - Preview</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #f5f5f5;
        }
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 20px;
        }
        header {
          background-color: #1a56db;
          color: white;
          padding: 20px;
          text-align: center;
        }
        .products {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 20px;
          margin-top: 30px;
        }
        .product-card {
          background-color: #fff;
          border-radius: 8px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
          overflow: hidden;
        }
        .product-image {
          width: 100%;
          height: 200px;
          object-fit: cover;
        }
        .product-info {
          padding: 15px;
        }
        .product-price {
          font-weight: bold;
          color: #1a56db;
          margin-top: 5px;
        }
        .features {
          display: flex;
          flex-wrap: wrap;
          gap: 5px;
          margin-top: 10px;
        }
        .feature {
          background-color: #e0e7ff;
          color: #1a56db;
          padding: 4px 8px;
          border-radius: 4px;
          font-size: 12px;
        }
      </style>
    </head>
    <body>
      <header>
        <h1>Widget Security Systems</h1>
        <p>Professional CCTV & Security Solutions</p>
      </header>
      
      <div class="container">
        <h2>Our Top Security Products</h2>
        
        <div class="products">
          ${productCards}
        </div>
      </div>
    </body>
    </html>
  `;
};

// Main route
app.get('/', (req, res) => {
  res.send(generateHTML());
});

// API routes
app.get('/api/products', (req, res) => {
  res.json(products);
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (!product) {
    return res.status(404).json({ message: 'Product not found' });
  }
  res.json(product);
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Replit Demo Server running on port ${PORT}`);
});
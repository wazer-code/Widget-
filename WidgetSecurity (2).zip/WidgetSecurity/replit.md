# Overview

This is a professional security systems and CCTV company website built with a modern full-stack architecture. The application provides a comprehensive platform for showcasing security products (CCTV systems, alarm systems, access control, smart security), services, company information, and customer engagement features including testimonials, FAQ, and contact forms.

The system is designed as a complete business website for a security company called "SecureTech" with features for product browsing, service information, customer testimonials, installation gallery, and lead generation through contact forms.

## Recent Changes (August 2025)
- ✅ **Website Fully Functional**: Successfully resolved React Query configuration issues that were preventing products from displaying
- ✅ **API Integration**: All endpoints (/api/products, /api/services, /api/testimonials, /api/gallery, /api/faqs) working correctly
- ✅ **Query Client Fixed**: Updated query client to use relative URLs instead of absolute localhost URLs for proper Vite dev server proxying
- ✅ **Project Optimization**: Reduced project size from 26MB to 2MB for deployment compatibility
- ✅ **Debugging Infrastructure**: Added comprehensive logging for troubleshooting data flow issues
- ✅ **User Confirmation**: Website confirmed working by user on August 24, 2025
- ✅ **Admin Panel with Authentication**: Added password-protected admin panel (/admin) with login system (admin/admin123)
- ✅ **Shopping Cart System**: Implemented full e-commerce cart functionality with cart context, cart page, and checkout process
- ✅ **Enhanced UI Design**: Added variety to the UI with gradient backgrounds, glass morphism effects, and smooth animations
- ✅ **Advanced Animations**: Implemented cursor interactions, hover effects, page transitions, and enhanced visual feedback
- ✅ **Order Management**: Created customer order system that saves to PostgreSQL database with admin management capabilities

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent, professional UI
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Forms**: React Hook Form with Zod validation for robust form handling
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for full-stack type safety
- **API Design**: RESTful API with structured endpoints for products, services, testimonials, etc.
- **Development Mode**: Vite dev server with HMR for seamless development experience
- **Production**: Express server serving built static assets

## Database Layer
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon Database)
- **Schema**: Structured tables for users, products, services, testimonials, gallery images, FAQs, and contact submissions
- **Migration Management**: Drizzle Kit for database schema migrations

## Project Structure
- **Shared Schema**: Common TypeScript types and Zod validation schemas in `/shared`
- **Client**: React frontend application in `/client` directory
- **Server**: Express backend API in `/server` directory
- **Asset Management**: Static assets served from `attached_assets` and `public/assets` directories

## Development Features
- **Hot Module Replacement**: Fast development with Vite HMR
- **Type Safety**: End-to-end TypeScript with shared types between frontend and backend
- **Code Organization**: Clean separation of concerns with dedicated directories for components, pages, hooks, and utilities
- **Responsive Design**: Mobile-first approach with Tailwind CSS responsive utilities

## Production Considerations
- **Static Asset Serving**: Optimized asset delivery with proper caching strategies
- **Build Optimization**: Vite production builds with code splitting and tree shaking
- **Deployment Ready**: Configured for Vercel deployment with appropriate build settings

# External Dependencies

## Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form for frontend framework and form management
- **TypeScript**: Full-stack type safety with TSX support
- **Vite**: Modern build tool with plugins for React and TypeScript

## UI and Styling
- **Tailwind CSS**: Utility-first CSS framework with custom theme configuration
- **Radix UI**: Headless UI components for accessibility and consistent behavior
- **shadcn/ui**: Pre-built component library built on Radix UI primitives
- **Lucide React**: Modern icon library for consistent iconography
- **Font Awesome**: Additional icon support via CDN

## Backend and API
- **Express.js**: Web application framework for Node.js
- **TanStack Query**: Server state management and caching for React
- **Zod**: Schema validation for forms and API data

## Database and ORM
- **Drizzle ORM**: Type-safe ORM for PostgreSQL database operations
- **Neon Database**: Serverless PostgreSQL database provider
- **PostgreSQL**: Primary database for production data storage

## Development Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **TSX**: TypeScript execution for development server
- **PostCSS**: CSS processing with Autoprefixer for browser compatibility

## Third-party Services
- **Google Fonts**: Web fonts (Inter and Poppins) for typography
- **Unsplash**: Stock photography for hero sections and placeholders
- **Social Media APIs**: Integration points for Facebook, Twitter, LinkedIn, Instagram

## Deployment Platforms
- **Vercel**: Primary deployment target with optimized configuration
- **Netlify**: Alternative deployment option with serverless functions
- **Replit**: Development environment support with custom server configurations
#!/bin/bash
node simple-html-server.js
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON requests
app.use(express.json());

// Serve static files from the public/assets directory
app.use('/assets', express.static(path.join(__dirname, 'public/assets')));

// Fallback to attached_assets if file not found in public/assets
app.use('/assets', (req, res, next) => {
  const requestedAsset = path.join(__dirname, 'attached_assets', path.basename(req.path));
  if (fs.existsSync(requestedAsset)) {
    res.sendFile(requestedAsset);
  } else {
    next();
  }
});

// Serve the static HTML file
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'simple.html'));
});

// Sample data
const products = [
  {
    id: 1,
    name: "Ultra HD CCTV System",
    price: 499.99,
    description: "Complete 4K Ultra HD security camera system with night vision, motion detection, and smartphone connectivity.",
    imageUrl: "/assets/IMG_0974.jpeg",
    category: "cctv",
    rating: 4.8,
    features: ["4K Resolution", "Night Vision", "Weatherproof", "Motion Detection"]
  },
  {
    id: 2,
    name: "Smart Alarm Pro",
    price: 449.99,
    description: "Comprehensive alarm system with door/window sensors, motion detectors, and smart integration.",
    imageUrl: "/assets/IMG_0990.jpeg",
    category: "alarm",
    rating: 5.0,
    features: ["Smartphone Control", "Smart Home", "Wireless", "Sirens"]
  },
  {
    id: 3,
    name: "Biometric Access Control",
    price: 599.99,
    description: "Advanced biometric fingerprint and facial recognition system for secured access control.",
    imageUrl: "/assets/IMG_1007.jpeg",
    category: "access",
    rating: 4.5,
    features: ["Biometric", "Facial Recognition", "App Control", "Multi-user"]
  },
  {
    id: 4,
    name: "Smart Home Security Hub",
    price: 799.99,
    description: "Central hub that connects all your security devices, with voice control and AI monitoring.",
    imageUrl: "/assets/IMG_1011.jpeg",
    category: "smart",
    rating: 4.7,
    features: ["Voice Control", "AI Monitoring", "Cloud Storage", "API Integration"]
  }
];

const services = [
  {
    id: 1,
    name: "Security System Installation",
    description: "Professional installation of any security system, ensuring optimal coverage and performance.",
    price: 199.99,
    imageUrl: "/assets/IMG_0826.png",
    features: ["Expert technicians", "Warranty included", "Full testing", "User training"]
  },
  {
    id: 2,
    name: "24/7 Monitoring Service",
    description: "Round-the-clock professional monitoring of your security systems with immediate response protocols.",
    price: 49.99,
    imageUrl: "/assets/IMG_1011.jpeg",
    features: ["Always on", "Alert notifications", "Emergency dispatch", "Monthly reports"]
  },
  {
    id: 3,
    name: "Security Consultation",
    description: "Comprehensive security assessment and customized recommendations for your property.",
    price: 299.99,
    imageUrl: "/assets/IMG_0990.jpeg",
    features: ["Vulnerability assessment", "Custom solutions", "Budget planning", "Implementation strategy"]
  }
];

// API Endpoints
app.get('/api/products', (req, res) => {
  res.json(products);
});

app.get('/api/products/:id', (req, res) => {
  const product = products.find(p => p.id === parseInt(req.params.id));
  if (!product) return res.status(404).json({ message: "Product not found" });
  res.json(product);
});

app.get('/api/services', (req, res) => {
  res.json(services);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://0.0.0.0:${PORT}/`);
});
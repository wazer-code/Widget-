#!/bin/bash
pkill node  # Kill any existing Node processes
node replit-server.js  # Start our simpler server
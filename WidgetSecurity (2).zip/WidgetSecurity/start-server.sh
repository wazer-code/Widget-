#!/bin/bash
echo "Starting simple HTML server on port 3000..."
node simple-html-server.js